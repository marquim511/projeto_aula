public class Laboratorio {
    private String nome;
    private int capacidade;
    private boolean equipado;

    public Laboratorio(String nome, int capacidade, boolean equipado) {
        this.nome = nome;
        this.capacidade = capacidade;
        this.equipado = equipado;
    }

    // Métodos Get
    public String getNome() {
        return nome;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public boolean isEquipado() {
        return equipado;
    }

    // Métodos Set
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public void setEquipado(boolean equipado) {
        this.equipado = equipado;
    }
}