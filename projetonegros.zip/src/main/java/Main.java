public class Main {
    public static void main(String[] args) {
        // Criando uma instância de Laboratorio
        Laboratorio lab = new Laboratorio("Lab 1", 20, true);

        // Exibindo detalhes do laboratório
        System.out.println("Nome: " + lab.getNome());
        System.out.println("Capacidade: " + lab.getCapacidade());
        System.out.println("Equipado: " + (lab.isEquipado() ? "Sim" : "Não"));

        // Modificando os detalhes do laboratório
        lab.setNome("Lab 2");
        lab.setCapacidade(30);
        lab.setEquipado(false);

        // Exibindo os detalhes atualizados do laboratório
        System.out.println("\nDetalhes atualizados do laboratório:");
        System.out.println("Nome: " + lab.getNome());
        System.out.println("Capacidade: " + lab.getCapacidade());
        System.out.println("Equipado: " + (lab.isEquipado() ? "Sim" : "Não"));
    }
}

  
